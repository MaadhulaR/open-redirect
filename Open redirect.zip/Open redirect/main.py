# main.py
import argparse
from modules.banner import show_banner
from modules.netcheck import validate_network
from utils.scanner import perform_scan  # Ensure this points to the enhanced perform_scan
from utils.file_ops import load_urls
from utils.output import save_results
from modules.urls import BLOG_URL

def main():
    parser = argparse.ArgumentParser(description="Open Redirect Bug Finder Tool")
    parser.add_argument('-u', '--url', help="URL to scan for open redirect vulnerabilities")
    parser.add_argument('-i', '--input', help="Input file containing URLs to scan")
    parser.add_argument('-o', '--output', help="Output file to save the scan results")
    parser.add_argument('-b', '--blog', action='store_true', help="Open the blog URL in the browser")
    args = parser.parse_args()

    show_banner()
    validate_network()

    results = []

    if args.blog:
        print(f"Opening blog URL: {BLOG_URL}")
        import webbrowser
        webbrowser.open(BLOG_URL)
    else:
        if args.url:
            print(f"Scanning URL: {args.url}")
            result = perform_scan(args.url)
            results.append(result)
            print(f"Scan result: {result}")
        if args.input:
            urls = load_urls(args.input)
            print(f"Loaded URLs: {urls}")
            for url in urls:
                print(f"Scanning URL from file: {url}")
                result = perform_scan(url)
                results.append(result)
                print(f"Scan result for {url}: {result}")
        if args.output:
            print(f"Saving results to {args.output}")
            save_results(results, args.output)
            print(f"\nResults saved to {args.output}")

if __name__ == "__main__":
    main()
