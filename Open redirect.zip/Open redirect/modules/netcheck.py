# modules/netcheck.py
import requests

def validate_network():
    try:
        requests.get('http://www.google.com', timeout=3)
        print("Network check: OK")
    except requests.ConnectionError:
        print("Network check: FAILED")
        exit(1)
