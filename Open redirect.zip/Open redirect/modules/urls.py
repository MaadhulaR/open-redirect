# modules/urls.py
BLOG_URL = "https://your-blog-url.com"
