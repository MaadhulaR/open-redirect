import requests
from urllib.parse import urlparse, parse_qs

def perform_scan(url):
    """
    Scan the given URL for open redirect vulnerabilities.
    
    Parameters:
        url (str): The URL to scan.
    
    Returns:
        str: The scan result.
    """
    try:
        response = requests.get(url, allow_redirects=True, timeout=10)
        final_url = response.url

        # Check for absolute URL redirects in query parameters
        query_params = parse_qs(urlparse(url).query)
        for param in query_params:
            for redirect_url in query_params[param]:
                if is_absolute_url(redirect_url):
                    return f"Scanned URL: {url} - Result: Potential open redirect detected via parameter {param} to {redirect_url}"

        # Check for meta refresh and JavaScript redirects if content type is HTML
        if 'text/html' in response.headers.get('Content-Type', ''):
            if is_meta_refresh_redirect(response.text):
                return f"Scanned URL: {url} - Result: Potential open redirect detected via meta refresh"
            if is_javascript_redirect(response.text):
                return f"Scanned URL: {url} - Result: Potential open redirect detected via JavaScript"

        return f"Scanned URL: {url} - Result: No open redirect detected"

    except requests.RequestException as e:
        return f"Scanned URL: {url} - Error: {str(e)}"

def is_absolute_url(url):
    return urlparse(url).scheme in ['http', 'https']

def is_meta_refresh_redirect(html_content):
    """
    Check for meta refresh redirects in HTML content.
    
    Parameters:
        html_content (str): The HTML content to check.
    
    Returns:
        bool: True if a meta refresh redirect is found, False otherwise.
    """
    import re
    meta_refresh_pattern = re.compile(r'<meta\s+http-equiv=["\']refresh["\']\s+content=["\'][^;]*;?\s*url=([^"\']*)["\']', re.IGNORECASE)
    match = meta_refresh_pattern.search(html_content)
    return match is not None

def is_javascript_redirect(html_content):
    """
    Check for JavaScript-based redirects in HTML content.
    
    Parameters:
        html_content (str): The HTML content to check.
    
    Returns:
        bool: True if a JavaScript redirect is found, False otherwise.
    """
    import re
    js_redirect_pattern = re.compile(r'window\.location\.href\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
    match = js_redirect_pattern.search(html_content)
    return match is not None
