# utils/file_ops.py

def load_urls(input_file):
    with open(input_file, 'r') as file:
        urls = file.read().splitlines()
    return urls
